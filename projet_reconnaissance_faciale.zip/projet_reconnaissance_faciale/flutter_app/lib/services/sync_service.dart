import 'api_service.dart';
import 'database_service.dart';

class SyncService {
  final ApiService _apiService = ApiService();
  final DatabaseService _dbService = DatabaseService.instance;

  Future<bool> syncAttendances() async {
    try {
      final unsyncedAttendances = await _dbService.getUnsyncedAttendances();

      if (unsyncedAttendances.isEmpty) {
        return true;
      }

      final attendancesData = unsyncedAttendances
          .map((att) => {
                'localId': att.localId,
                'employee_id': att.employeeId,
                'date': att.date,
                'arrival_time': att.arrivalTime,
                'departure_time': att.departureTime,
                'status': att.status,
              })
          .toList();

      final success = await _apiService.syncAttendances(attendancesData);

      if (success) {
        for (var att in unsyncedAttendances) {
          if (att.localId != null) {
            await _dbService.markAsSynced(att.localId!);
          }
        }
      }

      return success;
    } catch (e) {
      return false;
    }
  }
}
