import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import '../providers/auth_provider.dart';
import 'dart:io'; // ✅ pour utiliser File

class FaceDetectionScreen extends StatefulWidget {
  const FaceDetectionScreen({Key? key}) : super(key: key);

  @override
  State<FaceDetectionScreen> createState() => _FaceDetectionScreenState();
}

class _FaceDetectionScreenState extends State<FaceDetectionScreen> {
  bool _loading = false;
  String? _message;
  String? _employeeName;
  XFile? _capturedImage;
  final ImagePicker _picker = ImagePicker();

  Future<void> _detectFaceFromCamera() async {
    setState(() {
      _loading = true;
      _message = null;
      _employeeName = null;
      _capturedImage = null;
    });

    final auth = Provider.of<AuthProvider>(context, listen: false);

    try {
      // 📸 Capture image depuis la caméra
      final pickedFile = await _picker.pickImage(source: ImageSource.camera);
      if (pickedFile == null) {
        setState(() {
          _message = 'Aucune image capturée';
          _loading = false;
        });
        return;
      }

      // 🔄 Encode l’image en base64
      final bytes = await pickedFile.readAsBytes();
      final imageBase64 = base64Encode(bytes);

      // 🚀 Envoie au backend
      final result = await auth.apiService.detectFace(
        imageBase64: imageBase64,
        location: 'main_entrance',
      );

      print('Résultat détection: $result');

      setState(() {
        _message = result['message'];
        _employeeName = result['employee']?['name'];
        _capturedImage = pickedFile;
        _loading = false;
      });

      // ✅ Feedback visuel
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_message ?? 'Détection terminée')),
      );
    } catch (e) {
      setState(() {
        _message = 'Erreur: ${e.toString()}';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Détection Faciale')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const Icon(Icons.face, size: 100, color: Colors.blue),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _loading ? null : _detectFaceFromCamera,
              icon: const Icon(Icons.camera_alt),
              label: const Text('Détecter le visage'),
            ),
            const SizedBox(height: 16),
            if (_loading) const CircularProgressIndicator(),
            if (_capturedImage != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Image.file(
                  File(_capturedImage!.path),
                  height: 200,
                ),
              ),
            if (_message != null)
              Card(
                color: Colors.green.shade50,
                child: ListTile(
                  leading: const Icon(Icons.check_circle, color: Colors.green),
                  title: Text(_message ?? ''),
                  subtitle: _employeeName != null
                      ? Text('Employé : $_employeeName')
                      : null,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
