// ============================================
// SERVER.JS - Backend Node.js + Express + JWT
// Application de Reconnaissance Faciale
// ============================================

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');

// Initialisation de l'application Express
const app = express();

// Configuration
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'your-secret-key-change-this-in-production';

// Middleware
app.use(cors()); // Permettre les requêtes cross-origin
app.use(express.json()); // Parser le JSON
app.use(express.urlencoded({ extended: true }));

// ============================================
// CONFIGURATION DE LA BASE DE DONNÉES
// ============================================

// Pool de connexions MySQL
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '160305', // ⚠️ CHANGEZ CECI
  database: 'jwtauth',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Fonction pour tester la connexion
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('✅ Connexion MySQL réussie');
    connection.release();
  } catch (error) {
    console.error('❌ Erreur connexion MySQL:', error.message);
    console.log('💡 Vérifiez que MySQL est démarré et que les identifiants sont corrects');
  }
}

// ============================================
// MIDDLEWARE D'AUTHENTIFICATION JWT
// ============================================

function verifyToken(req, res, next) {
  const token = req.headers['x-access-token'];

  if (!token) {
    return res.status(403).json({
      error: 'Aucun token fourni'
    });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({
        error: 'Token invalide ou expiré'
      });
    }
    
    req.userId = decoded.id;
    req.userEmail = decoded.email;
    next();
  });
}

// ============================================
// ROUTES D'AUTHENTIFICATION
// ============================================

// Route de test
app.get('/', (req, res) => {
  res.json({
    message: 'API Reconnaissance Faciale',
    version: '1.0.0',
    status: 'running'
  });
});

// Route de health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

// ============================================
// INSCRIPTION (Sign Up)
// ============================================
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { username, email, password, employee_id } = req.body;
    console.log('📥 Reçu depuis Flutter:', req.body);


    // Validation des champs
    if (!username || !email || !password || !employee_id) {
      return res.status(400).json({
        error: 'Tous les champs sont requis'
      });
    }

    // Vérification du format de l'email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        error: 'Format d\'email invalide'
      });
    }

    // Vérification de la longueur du mot de passe
    if (password.length < 6) {
      return res.status(400).json({
        error: 'Le mot de passe doit contenir au moins 6 caractères'
      });
    }

    // Vérifier si l'email ou le matricule existe déjà
    const [existingUsers] = await pool.query(
      'SELECT id FROM users WHERE email = ? OR employee_id = ?',
      [email, employee_id]
    );

    if (existingUsers.length > 0) {
      return res.status(409).json({
        error: 'Email ou matricule déjà utilisé'
      });
    }

    // Hasher le mot de passe
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insérer l'utilisateur
    const [result] = await pool.query(
      'INSERT INTO users (username, email, password, employee_id) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, employee_id]
    );

    // Générer le token JWT
    const token = jwt.sign(
      { id: result.insertId, email, employee_id },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    // Réponse
    res.status(201).json({
      message: 'Inscription réussie',
      accessToken: token,
      user: {
        id: result.insertId,
        username,
        email,
        employee_id
      }
    });

  } catch (error) {
    console.error('❌ Erreur signup:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      details: error.message
    });
  }
});

// ============================================
// CONNEXION (Sign In)
// ============================================
app.post('/api/auth/signin', async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log('📥 Tentative de connexion:', email);

    // Validation
    if (!email || !password) {
      return res.status(400).json({
        error: 'Email et mot de passe requis'
      });
    }

    // Rechercher l'utilisateur
    const [users] = await pool.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({
        error: 'Email ou mot de passe incorrect'
      });
    }

    const user = users[0];

    // Vérifier le mot de passe
    const passwordValid = await bcrypt.compare(password, user.password);

    if (!passwordValid) {
      return res.status(401).json({
        error: 'Email ou mot de passe incorrect'
      });
    }

    // Générer le token JWT
    const token = jwt.sign(
      { id: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    console.log('✅ Connexion réussie:', user.email);

    res.json({
      message: 'Connexion réussie',
      accessToken: token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email
      }
    });

  } catch (error) {
    console.error('Erreur signin:', error);
    res.status(500).json({
      error: 'Erreur lors de la connexion',
      details: error.message
    });
  }
});

// ============================================
// ROUTES POINTAGES (ATTENDANCES)
// ============================================

// Récupérer les pointages de l'utilisateur connecté
app.get('/api/attendances/my-records', verifyToken, async (req, res) => {
  try {
    console.log('📥 Récupération pointages pour user:', req.userId);

    // Récupérer les pointages (simplifiés pour l'exemple)
    const [attendances] = await pool.query(
      `SELECT a.*, e.first_name, e.last_name 
       FROM attendances a 
       LEFT JOIN employees e ON a.employee_id = e.id 
       ORDER BY a.date DESC, a.arrival_time DESC 
       LIMIT 50`
    );

    res.json({
      success: true,
      attendances: attendances.map(att => ({
        id: att.id,
        employee_id: att.employee_id,
        date: att.date,
        arrival_time: att.arrival_time,
        departure_time: att.departure_time,
        first_name: att.first_name,
        last_name: att.last_name
      }))
    });

  } catch (error) {
    console.error('Erreur récupération pointages:', error);
    res.status(500).json({
      error: 'Erreur lors de la récupération des pointages',
      details: error.message
    });
  }
});

// Récupérer tous les pointages (Admin)
app.get('/api/attendances/all', verifyToken, async (req, res) => {
  try {
    const { date, employeeId, status } = req.query;

    let query = 'SELECT * FROM attendances WHERE 1=1';
    const params = [];

    if (date) {
      query += ' AND date = ?';
      params.push(date);
    }

    if (employeeId) {
      query += ' AND employee_id = ?';
      params.push(employeeId);
    }

    query += ' ORDER BY date DESC, arrival_time DESC LIMIT 100';

    const [attendances] = await pool.query(query, params);

    res.json({
      success: true,
      count: attendances.length,
      attendances: attendances
    });

  } catch (error) {
    console.error('Erreur récupération tous pointages:', error);
    res.status(500).json({
      error: 'Erreur lors de la récupération',
      details: error.message
    });
  }
});

// Synchroniser les pointages hors ligne
app.post('/api/attendances/sync', verifyToken, async (req, res) => {
  try {
    const { attendances } = req.body;

    if (!Array.isArray(attendances) || attendances.length === 0) {
      return res.status(400).json({
        error: 'Données de synchronisation invalides'
      });
    }

    const syncResults = {
      success: [],
      failed: [],
      duplicates: []
    };

    for (const att of attendances) {
      try {
        // Vérifier si existe déjà
        const [existing] = await pool.query(
          'SELECT id FROM attendances WHERE employee_id = ? AND date = ? AND arrival_time = ?',
          [att.employee_id, att.date, att.arrival_time]
        );

        if (existing.length > 0) {
          syncResults.duplicates.push({
            localId: att.localId,
            serverId: existing[0].id
          });
          continue;
        }

        // Créer nouveau pointage
        const [result] = await pool.query(
          'INSERT INTO attendances (employee_id, date, arrival_time, departure_time, status, location) VALUES (?, ?, ?, ?, ?, ?)',
          [
            att.employee_id,
            att.date,
            att.arrival_time,
            att.departure_time || null,
            att.status || 'present',
            att.location || 'main_entrance'
          ]
        );

        syncResults.success.push({
          localId: att.localId,
          serverId: result.insertId
        });

      } catch (err) {
        syncResults.failed.push({
          localId: att.localId,
          error: err.message
        });
      }
    }

    res.json({
      success: true,
      message: 'Synchronisation terminée',
      results: syncResults
    });

  } catch (error) {
    console.error('Erreur synchronisation:', error);
    res.status(500).json({
      error: 'Erreur lors de la synchronisation',
      details: error.message
    });
  }
});

// ============================================
// ROUTE DÉTECTION FACIALE (SIMULATION)
// ============================================

app.post('/api/face/detect', async (req, res) => {
  try {
    const { imageBase64, location = 'main_entrance' } = req.body;

    console.log('📷 Détection faciale demandée');

    // SIMULATION : En production, vous appelleriez votre API YOLO ici
    // Pour l'instant, on simule une détection réussie

    const employeeId = 'E001'; // Simulé
    const now = new Date();
    const date = now.toISOString().split('T')[0];
    const time = now.toTimeString().split(' ')[0];

    // Insérer le pointage
    await pool.query(
      'INSERT INTO attendances (employee_id, date, arrival_time, location) VALUES (?, ?, ?, ?)',
      [employeeId, date, time, location]
    );

    res.json({
      success: true,
      type: 'arrival',
      message: 'Bonjour Employé E001',
      employee: {
        id: employeeId,
        name: 'Employé Test'
      }
    });

  } catch (error) {
    console.error('Erreur détection faciale:', error);
    res.status(500).json({
      error: 'Erreur lors de la détection',
      details: error.message
    });
  }
});

// ============================================
// ROUTES EMPLOYÉS
// ============================================

app.get('/api/employees', verifyToken, async (req, res) => {
  try {
    const [employees] = await pool.query(
      'SELECT id, first_name, last_name, email, department, position, status FROM employees'
    );

    res.json({
      success: true,
      employees: employees
    });

  } catch (error) {
    console.error('Erreur récupération employés:', error);
    res.status(500).json({
      error: 'Erreur lors de la récupération des employés'
    });
  }
});

app.get('/api/employees/me', verifyToken, async (req, res) => {
  try {
    const [users] = await pool.query(
      'SELECT id, username, email FROM users WHERE id = ?',
      [req.userId]
    );

    if (users.length === 0) {
      return res.status(404).json({
        error: 'Utilisateur non trouvé'
      });
    }

    res.json({
      success: true,
      user: users[0]
    });

  } catch (error) {
    res.status(500).json({
      error: 'Erreur lors de la récupération du profil'
    });
  }
});

// ============================================
// GESTION DES ERREURS 404
// ============================================

app.use((req, res) => {
  res.status(404).json({
    error: 'Route non trouvée',
    path: req.path
  });
});

// ============================================
// DÉMARRAGE DU SERVEUR
// ============================================

async function startServer() {
  // Tester la connexion à la base de données
  await testConnection();

  // Démarrer le serveur
  app.listen(PORT, () => {
    console.log('');
    console.log('========================================');
    console.log('  🚀 Serveur Backend démarré !');
    console.log('========================================');
    console.log(`  📡 Port: ${PORT}`);
    console.log(`  🌐 URL: http://localhost:${PORT}`);
    console.log(`  📊 API: http://localhost:${PORT}/api`);
    console.log('========================================');
    console.log('');
    console.log('Routes disponibles:');
    console.log('  POST /api/auth/signin    - Connexion');
    console.log('  POST /api/auth/signup    - Inscription');
    console.log('  GET  /api/attendances/my-records - Mes pointages');
    console.log('  POST /api/face/detect    - Détection faciale');
    console.log('');
    console.log('💡 Appuyez sur Ctrl+C pour arrêter le serveur');
    console.log('');
  });
}

// Lancer le serveur
startServer();

// Gestion de l'arrêt propre
process.on('SIGINT', () => {
  console.log('\n👋 Arrêt du serveur...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n👋 Arrêt du serveur...');
  process.exit(0);
});