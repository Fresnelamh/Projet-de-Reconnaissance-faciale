import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:3000';

  // --- Connexion ---
  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/auth/signin'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception(_extractErrorMessage(response));
      }
    } catch (e) {
      throw Exception('Erreur réseau: $e');
    }
  }

  // --- Inscription ---
  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
    required String employeeId,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/auth/signup'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'username': name,
          'email': email,
          'password': password,
          'employee_id': employeeId,
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        throw Exception(_extractErrorMessage(response));
      }
    } catch (e) {
      throw Exception('Erreur réseau: $e');
    }
  }

  // --- Profil utilisateur ---
  Future<Map<String, dynamic>?> getProfile({required String token}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/auth/me'),
        headers: {
          'Content-Type': 'application/json',
          'x-access-token': token,
        },
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return null;
      }
    } catch (e) {
      return null;
    }
  }

  // --- Récupération des présences ---
  Future<List<dynamic>> getAttendances() async {
    try {
      final token = await _getToken();
      final response = await http.get(
        Uri.parse('$baseUrl/api/attendances/my-records'),
        headers: {
          'Content-Type': 'application/json',
          'x-access-token': token,
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['attendances'] ?? [];
      } else {
        throw Exception(_extractErrorMessage(response));
      }
    } catch (e) {
      throw Exception('Erreur: $e');
    }
  }

  // --- Synchronisation des présences ---
  Future<bool> syncAttendances(List<Map<String, dynamic>> attendances) async {
    try {
      final token = await _getToken();
      final response = await http.post(
        Uri.parse('$baseUrl/api/attendances/sync'),
        headers: {
          'Content-Type': 'application/json',
          'x-access-token': token,
        },
        body: json.encode({'attendances': attendances}),
      );

      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // --- Détection faciale (simulation) ---
  Future<Map<String, dynamic>> detectFace({
    required String imageBase64,
    String location = 'main_entrance',
  }) async {
    try {
      final token = await _getToken();
      final response = await http.post(
        Uri.parse('$baseUrl/api/face/detect'),
        headers: {
          'Content-Type': 'application/json',
          'x-access-token': token,
        },
        body: json.encode({
          'imageBase64': imageBase64,
          'location': location,
        }),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception(_extractErrorMessage(response));
      }
    } catch (e) {
      throw Exception('Erreur détection: $e');
    }
  }

  // --- Récupération du token local ---
  Future<String> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    if (token == null) throw Exception('Token non trouvé');
    return token;
  }

  // --- Extraction du message d'erreur ---
  String _extractErrorMessage(http.Response response) {
    try {
      final jsonBody = json.decode(response.body);
      return jsonBody['message'] ?? jsonBody['error'] ?? 'Erreur inconnue';
    } catch (_) {
      return response.body.isNotEmpty
          ? response.body
          : 'Status ${response.statusCode}';
    }
  }
}
