import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/attendance_provider.dart';

class AttendancesScreen extends StatelessWidget {
  const AttendancesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Historique'),
      ),
      body: Consumer<AttendanceProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.attendances.isEmpty) {
            return const Center(child: Text('Aucun pointage enregistré'));
          }

          return ListView.builder(
            itemCount: provider.attendances.length,
            itemBuilder: (context, index) {
              final att = provider.attendances[index];
              return ListTile(
                title: Text('Employé: ${att.employeeId}'),
                subtitle: Text('${att.date} - ${att.arrivalTime}'),
                trailing: att.departureTime != null
                    ? Text(att.departureTime!)
                    : const Text('En cours',
                        style: TextStyle(color: Colors.orange)),
              );
            },
          );
        },
      ),
    );
  }
}
