from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import uvicorn
import cv2
import numpy as np
from ultralytics import YOLO
import base64
from typing import List, Optional
import pickle
import os

app = FastAPI(
    title="YOLO v8 Facial Recognition API",
    description="API de reconnaissance faciale, détection d'armes et d'animaux",
    version="1.0.0"
)

# Chargement des modèles
model_face = YOLO('models/yolov8n-face.pt')
model_weapon = YOLO('models/custom_trained/weapons_v1.pt')
model_animal = YOLO('models/yolov8n.pt')  # Modèle standard pour animaux

# Chargement des encodages faciaux
ENCODINGS_FILE = 'data/face_encodings.pkl'
face_encodings_db = {}

if os.path.exists(ENCODINGS_FILE):
    with open(ENCODINGS_FILE, 'rb') as f:
        face_encodings_db = pickle.load(f)

class DetectionRequest(BaseModel):
    image: str  # Base64
    detect_faces: bool = True
    detect_weapons: bool = False
    detect_animals: bool = False
    confidence_threshold: float = 0.5

class EncodeFaceRequest(BaseModel):
    image: str  # Base64
    employeeId: str

def base64_to_image(base64_string: str) -> np.ndarray:
    """Convertit base64 en image OpenCV"""
    try:
        # Retirer le préfixe si présent
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        img_data = base64.b64decode(base64_string)
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        return img
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Erreur décodage image: {str(e)}")

def image_to_base64(image: np.ndarray) -> str:
    """Convertit image OpenCV en base64"""
    _, buffer = cv2.imencode('.jpg', image)
    return base64.b64encode(buffer).decode('utf-8')

def get_face_encoding(face_img: np.ndarray) -> List[float]:
    """
    Génère un vecteur d'encodage facial (128 dimensions)
    Utilise les features de YOLO + embeddings
    """
    # Redimensionner pour uniformité
    face_resized = cv2.resize(face_img, (160, 160))
    
    # Extraction de features avec le modèle
    results = model_face(face_resized, verbose=False)
    
    # Simuler embedding (dans production, utiliser FaceNet, ArcFace, etc.)
    # Pour YOLO seul, on peut utiliser les features de la dernière couche
    # Ici, implémentation simplifiée
    face_gray = cv2.cvtColor(face_resized, cv2.COLOR_BGR2GRAY)
    face_flat = face_gray.flatten()
    
    # Réduction à 128 dimensions par PCA ou moyenne
    encoding = []
    step = len(face_flat) // 128
    for i in range(128):
        encoding.append(float(np.mean(face_flat[i*step:(i+1)*step])))
    
    return encoding

def compare_faces(encoding1: List[float], encoding2: List[float], threshold: float = 0.6) -> float:
    """Compare deux encodages faciaux, retourne la similarité (0-1)"""
    # Distance euclidienne
    enc1 = np.array(encoding1)
    enc2 = np.array(encoding2)
    distance = np.linalg.norm(enc1 - enc2)
    
    # Normaliser en similarité (0-1)
    similarity = 1 / (1 + distance)
    
    return similarity

@app.post("/api/detect")
async def detect(request: DetectionRequest):
    """
    Endpoint principal de détection
    Détecte visages, armes, animaux selon paramètres
    """
    try:
        # Décoder l'image
        img = base64_to_image(request.image)
        
        if img is None:
            raise HTTPException(status_code=400, detail="Image invalide")
        
        result = {
            "faces": [],
            "weapons": [],
            "animals": []
        }
        
        # DÉTECTION DES VISAGES
        if request.detect_faces:
            face_results = model_face(img, conf=request.confidence_threshold, verbose=False)
            
            for detection in face_results[0].boxes:
                x1, y1, x2, y2 = map(int, detection.xyxy[0])
                confidence = float(detection.conf[0])
                
                # Extraire le visage
                face_img = img[y1:y2, x1:x2]
                
                if face_img.size == 0:
                    continue
                
                # Générer encodage
                face_encoding = get_face_encoding(face_img)
                
                # Comparer avec la base de données
                identified = False
                best_match = None
                best_similarity = 0
                
                for employee_id, stored_encoding in face_encodings_db.items():
                    similarity = compare_faces(face_encoding, stored_encoding)
                    
                    if similarity > best_similarity and similarity > 0.6:  # Seuil de reconnaissance
                        best_similarity = similarity
                        best_match = employee_id
                        identified = True
                
                face_data = {
                    "bbox": [x1, y1, x2, y2],
                    "confidence": confidence,
                    "identified": identified,
                    "employeeId": best_match if identified else None,
                    "similarity": best_similarity if identified else 0
                }
                
                result["faces"].append(face_data)
        
        # DÉTECTION DES ARMES
        if request.detect_weapons:
            weapon_results = model_weapon(img, conf=request.confidence_threshold, verbose=False)
            
            for detection in weapon_results[0].boxes:
                x1, y1, x2, y2 = map(int, detection.xyxy[0])
                confidence = float(detection.conf[0])
                class_id = int(detection.cls[0])
                
                # Map class ID to weapon type
                weapon_types = {
                    0: "handgun",
                    1: "rifle",
                    2: "knife",
                    3: "other_weapon"
                }
                
                weapon_data = {
                    "type": weapon_types.get(class_id, "unknown"),
                    "bbox": [x1, y1, x2, y2],
                    "confidence": confidence
                }
                
                result["weapons"].append(weapon_data)
        
        # DÉTECTION DES ANIMAUX
        if request.detect_animals:
            animal_results = model_animal(img, conf=request.confidence_threshold, verbose=False)
            
            # Classes d'animaux dans COCO dataset
            animal_classes = [15, 16, 17, 18, 19, 20, 21, 22, 23]  # bird, cat, dog, etc.
            
            for detection in animal_results[0].boxes:
                class_id = int(detection.cls[0])
                
                if class_id in animal_classes:
                    x1, y1, x2, y2 = map(int, detection.xyxy[0])
                    confidence = float(detection.conf[0])
                    
                    animal_names = {
                        15: "bird",
                        16: "cat",
                        17: "dog",
                        18: "horse",
                        19: "sheep",
                        20: "cow"
                    }
                    
                    animal_data = {
                        "type": animal_names.get(class_id, "animal"),
                        "bbox": [x1, y1, x2, y2],
                        "confidence": confidence
                    }
                    
                    result["animals"].append(animal_data)
        
        return JSONResponse(content=result)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur détection: {str(e)}")

@app.post("/api/encode-face")
async def encode_face(request: EncodeFaceRequest):
    """
    Crée un encodage facial pour un nouvel employé
    """
    try:
        # Décoder l'image
        img = base64_to_image(request.image)
        
        if img is None:
            raise HTTPException(status_code=400, detail="Image invalide")
        
        # Détecter le visage
        face_results = model_face(img, conf=0.5, verbose=False)
        
        if len(face_results[0].boxes) == 0:
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "error": "Aucun visage détecté dans l'image"
                }
            )
        
        # Prendre le premier visage (ou le plus grand)
        detection = face_results[0].boxes[0]
        x1, y1, x2, y2 = map(int, detection.xyxy[0])
        
        # Extraire le visage
        face_img = img[y1:y2, x1:x2]
        
        # Générer l'encodage
        encoding = get_face_encoding(face_img)
        
        # Évaluer la qualité (basé sur taille, netteté, etc.)
        face_area = (x2 - x1) * (y2 - y1)
        img_area = img.shape[0] * img.shape[1]
        face_ratio = face_area / img_area
        
        # Score de qualité (simplifié)
        quality = min(face_ratio * 5, 1.0)  # Plus le visage est grand, meilleure est la qualité
        
        # Ajouter à la base de données
        face_encodings_db[request.employeeId] = encoding
        
        # Sauvegarder
        with open(ENCODINGS_FILE, 'wb') as f:
            pickle.dump(face_encodings_db, f)
        
        # Sauvegarder aussi l'image du visage
        os.makedirs('data/employee_photos', exist_ok=True)
        cv2.imwrite(f'data/employee_photos/{request.employeeId}.jpg', face_img)
        
        return JSONResponse(content={
            "success": True,
            "employeeId": request.employeeId,
            "encoding": encoding,
            "quality": quality,
            "message": "Encodage facial créé avec succès"
        })
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur encodage: {str(e)}")

@app.delete("/api/delete-encoding/{employee_id}")
async def delete_encoding(employee_id: str):
    """Supprime l'encodage d'un employé"""
    try:
        if employee_id in face_encodings_db:
            del face_encodings_db[employee_id]
            
            # Sauvegarder
            with open(ENCODINGS_FILE, 'wb') as f:
                pickle.dump(face_encodings_db, f)
            
            # Supprimer la photo
            photo_path = f'data/employee_photos/{employee_id}.jpg'
            if os.path.exists(photo_path):
                os.remove(photo_path)
            
            return {"success": True, "message": "Encodage supprimé"}
        else:
            raise HTTPException(status_code=404, detail="Employé non trouvé")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur suppression: {str(e)}")

@app.get("/api/health")
async def health():
    """Health check de l'API"""
    return {
        "status": "healthy",
        "models_loaded": {
            "face": model_face is not None,
            "weapon": model_weapon is not None,
            "animal": model_animal is not None
        },
        "employees_registered": len(face_encodings_db)
    }

@app.get("/")
async def root():
    return {
        "message": "YOLO v8 Facial Recognition API",
        "version": "1.0.0",
        "endpoints": {
            "detect": "/api/detect",
            "encode_face": "/api/encode-face",
            "health": "/api/health",
            "docs": "/docs"
        }
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5000)