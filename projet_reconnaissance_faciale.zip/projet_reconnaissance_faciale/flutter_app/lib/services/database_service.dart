import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/attendance_model.dart';

class DatabaseService {
  static Database? _database;
  static final DatabaseService instance = DatabaseService._init();

  DatabaseService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('attendances.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE attendances (
        local_id INTEGER PRIMARY KEY AUTOINCREMENT,
        id INTEGER,
        employee_id TEXT NOT NULL,
        date TEXT NOT NULL,
        arrival_time TEXT NOT NULL,
        departure_time TEXT,
        status TEXT DEFAULT 'present',
        synced INTEGER DEFAULT 0
      )
    ''');
  }

  Future<int> insertAttendance(AttendanceModel attendance) async {
    final db = await instance.database;
    return await db.insert('attendances', attendance.toMap());
  }

  Future<List<AttendanceModel>> getUnsyncedAttendances() async {
    final db = await instance.database;
    final result = await db.query(
      'attendances',
      where: 'synced = ?',
      whereArgs: [0],
    );
    return result.map((map) => AttendanceModel.fromMap(map)).toList();
  }

  Future<List<AttendanceModel>> getAllAttendances() async {
    final db = await instance.database;
    final result =
        await db.query('attendances', orderBy: 'date DESC, arrival_time DESC');
    return result.map((map) => AttendanceModel.fromMap(map)).toList();
  }

  Future<int> markAsSynced(int localId) async {
    final db = await instance.database;
    return await db.update(
      'attendances',
      {'synced': 1},
      where: 'local_id = ?',
      whereArgs: [localId],
    );
  }

  Future<int> deleteAttendance(int localId) async {
    final db = await instance.database;
    return await db.delete(
      'attendances',
      where: 'local_id = ?',
      whereArgs: [localId],
    );
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
