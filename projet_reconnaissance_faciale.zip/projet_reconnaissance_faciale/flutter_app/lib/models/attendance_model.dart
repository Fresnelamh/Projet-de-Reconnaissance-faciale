class AttendanceModel {
  final int? id;
  final int? localId;
  final String employeeId;
  final String date;
  final String arrivalTime;
  final String? departureTime;
  final String status;
  final bool synced;

  AttendanceModel({
    this.id,
    this.localId,
    required this.employeeId,
    required this.date,
    required this.arrivalTime,
    this.departureTime,
    this.status = 'present',
    this.synced = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'local_id': localId,
      'employee_id': employeeId,
      'date': date,
      'arrival_time': arrivalTime,
      'departure_time': departureTime,
      'status': status,
      'synced': synced ? 1 : 0,
    };
  }

  factory AttendanceModel.fromMap(Map<String, dynamic> map) {
    return AttendanceModel(
      id: map['id'] as int?,
      localId: map['local_id'] as int?,
      employeeId: map['employee_id'] as String,
      date: map['date'] as String,
      arrivalTime: map['arrival_time'] as String,
      departureTime: map['departure_time'] as String?,
      status: map['status'] as String? ?? 'present',
      synced: (map['synced'] as int?) == 1,
    );
  }
}
