import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/database_service.dart';
import '../models/attendance.dart';
import '../models/attendance_model.dart';

class AttendanceProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  final DatabaseService _dbService = DatabaseService.instance;

  List<Attendance> _attendances = [];
  bool _isLoading = false;
  String? _error;

  List<Attendance> get attendances => _attendances;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadAttendances({bool fromLocal = false}) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      if (fromLocal) {
        final localAttendances = await _dbService.getAllAttendances();
        _attendances = localAttendances
            .map((att) => Attendance(
                  id: att.id,
                  employeeId: att.employeeId,
                  date: att.date,
                  arrivalTime: att.arrivalTime,
                  departureTime: att.departureTime,
                  status: att.status,
                ))
            .toList();
      } else {
        final data = await _apiService.getAttendances();
        _attendances = data.map((json) => Attendance.fromJson(json)).toList();
      }

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addAttendance(AttendanceModel attendance) async {
    try {
      await _dbService.insertAttendance(attendance);
      await loadAttendances(fromLocal: true);
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }
}
