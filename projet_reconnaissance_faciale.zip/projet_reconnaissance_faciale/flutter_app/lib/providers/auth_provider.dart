import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../models/user.dart';

class AuthProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  ApiService get apiService => _apiService;

  User? _user;
  String? _token;
  bool _isLoading = false;
  String? _error;

  User? get user => _user;
  String? get token => _token;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _user != null && _token != null;

  // --- Helpers internes ---
  void _setLoading(bool v) {
    _isLoading = v;
    notifyListeners();
  }

  void _setError(String? e) {
    _error = e;
    notifyListeners();
  }

  Future<void> _saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
    _token = token;
  }

  Future<void> _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    _token = null;
  }

  Future<String?> _loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  // --- Login ---
  Future<bool> login(String email, String password) async {
    _setLoading(true);
    _setError(null);

    try {
      final response = await _apiService.login(email, password);
      // On attend un objet contenant au minimum accessToken et user
      final accessToken =
          response['accessToken'] ?? response['token'] ?? response['jwt'];
      final userJson = response['user'] ?? response['data'];

      if (accessToken != null && userJson != null) {
        await _saveToken(accessToken);
        _user = User.fromJson(userJson);
        _setLoading(false);
        return true;
      } else {
        // Cas où le backend renvoie une erreur structurée
        final msg = response['message'] ??
            response['error'] ??
            'Réponse inattendue du serveur';
        _setError(msg.toString());
        _setLoading(false);
        return false;
      }
    } catch (e) {
      // Normaliser l'erreur pour l'affichage en UI
      final errStr = _extractErrorMessage(e);
      _setError(errStr);
      _setLoading(false);
      return false;
    }
  }

  // --- Register (inscription) ---
  /// Retourne true si inscription réussie.
  /// Comportement par défaut : après inscription on sauvegarde le token et l'utilisateur (auto-login).
  /// Si tu préfères renvoyer l'utilisateur vers la page de login, modifie `autoLoginAfterRegister` à false.
  Future<bool> register({
    required String name,
    required String email,
    required String password,
    required String employeeId,
    bool autoLoginAfterRegister = true,
  }) async {
    _setLoading(true);
    _setError(null);
    print({
      'username': name,
      'email': email,
      'password': password,
      'employee_id': employeeId,
    });

    try {
      final response = await _apiService.register(
        name: name,
        email: email,
        password: password,
        employeeId: employeeId,
      );

      final accessToken =
          response['accessToken'] ?? response['token'] ?? response['jwt'];
      final userJson = response['user'] ?? response['data'];

      if (accessToken != null && userJson != null) {
        if (autoLoginAfterRegister) {
          await _saveToken(accessToken);
          _user = User.fromJson(userJson);
        } else {
          // Si on ne veut pas auto-login, on peut sauvegarder seulement un message ou token selon ton choix.
          // Ici on sauvegarde quand même le token pour faciliter la suite (optionnel).
          await _saveToken(accessToken);
        }
        _setLoading(false);
        return true;
      } else {
        final msg = response['message'] ??
            response['error'] ??
            'Impossible d\'inscrire l\'utilisateur';
        _setError(msg.toString());
        _setLoading(false);
        return false;
      }
    } catch (e) {
      final errStr = _extractErrorMessage(e);
      _setError(errStr);
      _setLoading(false);
      return false;
    }
  }

  // --- Auto login au démarrage de l'app ---
  /// Récupère le token en mémoire et essaye d'obtenir le profil utilisateur via l'API.
  /// Retourne true si la session est restaurée.
  Future<bool> tryAutoLogin() async {
    _setLoading(true);
    _setError(null);

    try {
      final storedToken = await _loadToken();
      if (storedToken == null) {
        _setLoading(false);
        return false;
      }

      // On renseigne le token localement pour que ApiService puisse l'utiliser (si nécessaire)
      _token = storedToken;

      // Si ton ApiService propose un endpoint "me" ou "profile", utilise-le pour récupérer l'utilisateur
      final profileResponse = await _apiService.getProfile(token: storedToken);
      if (profileResponse != null && profileResponse['user'] != null) {
        _user = User.fromJson(profileResponse['user']);
        _setLoading(false);
        return true;
      } else if (profileResponse != null && profileResponse['data'] != null) {
        _user = User.fromJson(profileResponse['data']);
        _setLoading(false);
        return true;
      } else {
        // Si le backend ne propose pas de profil, tu peux considérer le token comme valide et attendre le premier call.
        _setLoading(false);
        return false;
      }
    } catch (e) {
      // token invalide / expiré -> suppression
      await _removeToken();
      _setError(null); // ne pas forcément polluer l'UI au démarrage
      _setLoading(false);
      return false;
    }
  }

  // --- Logout ---
  Future<void> logout() async {
    await _removeToken();
    _user = null;
    _setError(null);
    notifyListeners();
  }

  void clearError() {
    _setError(null);
  }

  // --- utilitaire pour extraire message d'erreur ---
  String _extractErrorMessage(Object e) {
    try {
      final s = e.toString();
      // Si c'est une Map ou DioError, adapte selon ton ApiService (ici on fait simple)
      return s;
    } catch (_) {
      return 'Une erreur est survenue';
    }
  }
}
