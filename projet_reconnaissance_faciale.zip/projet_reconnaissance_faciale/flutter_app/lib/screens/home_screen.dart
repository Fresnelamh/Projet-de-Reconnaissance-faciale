import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/attendance_provider.dart';
import '../providers/connectivity_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final attendanceProvider =
          Provider.of<AttendanceProvider>(context, listen: false);
      final connectivityProvider =
          Provider.of<ConnectivityProvider>(context, listen: false);

      attendanceProvider.loadAttendances(
        fromLocal: !connectivityProvider.isOnline,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final attendanceProvider = Provider.of<AttendanceProvider>(context);
    final connectivityProvider = Provider.of<ConnectivityProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Bonjour ${authProvider.user?.username ?? ""}'),
        actions: [
          if (!connectivityProvider.isOnline)
            const Padding(
              padding: EdgeInsets.only(right: 8.0),
              child: Icon(Icons.cloud_off, color: Colors.orange),
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              attendanceProvider.loadAttendances(
                fromLocal: !connectivityProvider.isOnline,
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.face),
                label: const Text('Détection faciale'),
                onPressed: () {
                  Navigator.pushNamed(context, '/detect');
                },
              ),
            ),
          ),
          Expanded(
            child: attendanceProvider.isLoading
                ? const Center(child: CircularProgressIndicator())
                : attendanceProvider.attendances.isEmpty
                    ? const Center(child: Text('Aucun pointage'))
                    : RefreshIndicator(
                        onRefresh: () => attendanceProvider.loadAttendances(
                          fromLocal: !connectivityProvider.isOnline,
                        ),
                        child: ListView.builder(
                          itemCount: attendanceProvider.attendances.length,
                          itemBuilder: (context, index) {
                            final att = attendanceProvider.attendances[index];
                            return Card(
                              margin: const EdgeInsets.all(8),
                              child: ListTile(
                                leading: const CircleAvatar(
                                  backgroundColor: Colors.green,
                                  child: Icon(Icons.check, color: Colors.white),
                                ),
                                title: Text('Employé: ${att.employeeId}'),
                                subtitle: Text('Date: ${att.date}'),
                                trailing: Text(
                                  att.arrivalTime,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
