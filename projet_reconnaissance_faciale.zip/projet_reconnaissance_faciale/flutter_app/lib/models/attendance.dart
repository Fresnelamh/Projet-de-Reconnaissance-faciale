class Attendance {
  final int? id;
  final String employeeId;
  final String date;
  final String arrivalTime;
  final String? departureTime;
  final String? status;

  Attendance({
    this.id,
    required this.employeeId,
    required this.date,
    required this.arrivalTime,
    this.departureTime,
    this.status,
  });

  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      id: json['id'] as int?,
      employeeId: json['employee_id'] as String,
      date: json['date'] as String,
      arrivalTime: json['arrival_time'] as String,
      departureTime: json['departure_time'] as String?,
      status: json['status'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'employee_id': employeeId,
      'date': date,
      'arrival_time': arrivalTime,
      'departure_time': departureTime,
      'status': status,
    };
  }
}
